class Config:
    def __init__(self, buildSize, probeSize, memSize, recordSizeMin, recordSizeMax, frameSize, numPartitions, VS, GrowthC, numPartitionsFixed, fudge):
        # all sizes are in bytess
        self.buildSize = buildSize
        self.probeSize = probeSize
        self.memSize = memSize
        self.recordSizeMin = recordSizeMin
        self.recordSizeMax = recordSizeMax
        self.frameSize = frameSize
        self.numPartitions = numPartitions
        self.VS = VS
        self.GrowthC = GrowthC
        self.numPartitionsFixed = numPartitionsFixed
        self.fudge=fudge

    def __str__(self):
        return "build size : %s , probe size: %s , mem: %s ,  partitions: %s" %(self.buildSize,  self.probeSize , self.memSize , self.numPartitions)