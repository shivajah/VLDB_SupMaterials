import json
from Experiment import *
from Plot import *

class ConfigFile:
    SIZES = {"b": 1, "KB": 1024, "MB": 1048576, "GB": 1073741824, "TB": 1099511627776}

    def __init__(self):
        self.buildSizes = [] #bytes
        self.probeSizes = [] #bytes
        self.frameSize = 32768#bytes
        self.memSizes = [] #bytes
        self.recordSize = 100 #bytes
        self.numPartitions = [2,10]
        self.rangeOverNumPartitions = True
        self.folderName = "defaultFolder"
        self.groupBy_fn_ = "lambda c: (c.buildSize, c.memSize)"
        self.select_fn_ = "lambda c: c.numPartitions"
        self.lineLabel_fn_ = "lambda g: \"(buildSize, memSize) = %s\" % (str(g))"
        self.xLabel = "Number of Partitions"
        self.xlog = False
        self.ylog = False
        self.VSPolicy = "LARGEST_SIZE"
        self.numPartitionsFixed = False;

    def processConfigFile(self, configFile):
        with open(configFile) as json_file:
            # Load data
            c = json.load(json_file)
            self.frameSize = c['frameSize']
            frameSizeUnit = self.SIZES.get(c['frameSizeUnit'])
            self.buildSizes = [i * self.SIZES.get(c['build/probeUnits']) for i in (c['buildSizes'])]
            self.probeSizes = [i * self.SIZES.get(c['build/probeUnits']) for i in (c['probeSizes'])]
            self.memSizes = [i * self.SIZES.get(c['memSizesUnits']) for i in (c['memSizes'])]
            self.recordSizeMin = c['recordSizeMin']*self.SIZES.get(c['recordSizeUnits'])
            self.recordSizeMax = c['recordSizeMax'] * self.SIZES.get(c['recordSizeUnits'])
            self.rangeOverNumPartitions = c['rangeOverNumPartitions']
            self.folderName = c['folderName']
            self.groupBy_fn_ = c['groupBy_fn']
            self.select_fn_ = c['select_fn']
            self.lineLabel_fn_ = c['lineLabel_fn']
            self.xLabel = c['xLabel']
            self.xlog = c['xlog']
            self.ylog = c['ylog']
            self.VSPolicy = c['VSPolicy']
            self.GrowthC = c['GrowthC']
            self.numPartitionsFixed = c['numPartitionsFixed']
            self.fudge = c['fudge']
            #Set number of Partitions based on being a range or discerete values
            numPartitions = c['numPartitions']
            if self.rangeOverNumPartitions:
                assert len(numPartitions) == 2
                start = numPartitions[0]
                end = numPartitions[1]
                self.numPartitions = [i for i in range(start, end + 1)]
            else:
                self.numPartitions = numPartitions
            print()



if len(sys.argv) != 2:
    print('Usage: %s <config_file>' % sys.argv[0])
    sys.exit(1)

configFile = ConfigFile()
configFile.processConfigFile(sys.argv[1])

E = Experiment(configFile)
E.run()
for r in E.runs:
    print(r.join)
    print("build: ", r.join.build.stats())
    print("probe: ", r.join.probe.stats())
    print("Join: ", r.join.stats())




# Do plots
buildDone = False
for ph in ['build', 'probe', 'total']:
    for m in Stats.getAttrNames():
        #m = "recursionDepth"
        P = Plot(runs = E.runs,
                 phase = ph,
                 outFolder = configFile.folderName+ '/' + ph,
                 outFile = ph + '_' + m + '.png',
                 ylabel =  "Time (ms)" if (m=="totalTimeSSD" or m=="totalTimeHDD") else "I/O (Frames)",
                 xlabel = configFile.xLabel,
                 xlog = configFile.xlog,
                 ylog  = configFile.ylog if m != "recursionDepth" else False,
                 metric_fn = lambda s: getattr(s, m),
                 groupBy_fn = eval(configFile.groupBy_fn_) ,
                 select_fn = eval(configFile.select_fn_) ,
                 lineLabel_fn = eval(configFile.lineLabel_fn_))
        P.plot()
