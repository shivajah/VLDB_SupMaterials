from Join_ import *
from Config import *


class Experiment:
    def __init__(self, configFile):
        self.configFile = configFile
        self.done = False
        self.runs = []

    def generateConfigs(self):
        assert len(self.configFile.buildSizes) == len(self.configFile.probeSizes)
        for bs, ps in zip(self.configFile.buildSizes, self.configFile.probeSizes):
            for m in self.configFile.memSizes:
                for p in self.configFile.numPartitions:
                    yield Config(bs, ps, m, self.configFile.recordSizeMin, self.configFile.recordSizeMax, self.configFile.frameSize, p, self.configFile.VSPolicy, self.configFile.GrowthC, self.configFile.numPartitionsFixed, self.configFile.fudge)

    def run(self):
        assert not self.done
        for c in self.generateConfigs():
            r = Run(c)
            self.runs.append(r)
            r.run()
        self.done = True


class Run:
    def __init__(self,config):
        self.config = config
        self.join = None

    def run(self):
        self.join = Join_(self.config)
        self.join.run()