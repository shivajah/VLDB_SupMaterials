from enum import Enum
import sys
import random as rand
import Join_
class VSPolicy(Enum):
    LARGEST_RECORD =1
    LARGEST_SIZE=2
    SMALLEST_RECORD=3
    SMALLEST_SIZE=4
    MEDIAN_RECORD=5
    MEDIAN_SIZE=6
    MAX_SIZE_MIN_RECORD=7
    RANDOM=8
    LARGEST_SIZE_SELF=9




class SelectVictim:
    def __init__(self, policy, memoryManager, spilledStatus):
        #assert isinstance(policy, VSPolicy)
        assert policy in VSPolicy.__members__
        self.policy=policy
        self.memoryManager = memoryManager
        self.spilledStatus = spilledStatus

    def select(self, victim, phase):
        if phase == Join_.JOINPHASE.BUILD:
            partitions = self.memoryManager.buildPartitions
        else:
            partitions = self.memoryManager.probePartitions

        if self.policy == "LARGEST_RECORD":
            return self.getPartitionWithLargestRecord(partitions)
        elif self.policy == "LARGEST_SIZE":
            return self.getPartitionWithLargestSize(partitions)
        elif self.policy == "SMALLEST_RECORD":
            return self.getPartitionWithSmallestRecord(partitions)
        elif self.policy ==  "SMALLEST_SIZE":
            return self.getPartitionWithSmallestSize(partitions)
        elif self.policy == "MEDIAN_RECORD":
            return self.getPartitionWithMedianRecord(partitions)
        elif self.policy == "MEDIAN_SIZE":
            return self.getPartitionWithMedianSize(partitions)
        elif self.policy == "MAX_SIZE_MIN_RECORD":
            return self.getPartitionWithMaxSizeMinRecord(partitions)
        elif self.policy == "RANDOM":
            return self.getPartitionRandomly(partitions)
        elif self.policy == "LARGEST_SIZE_SELF":
            return self.getPartitionWithLargestSizeSelf(victim, partitions)



    def getPartitionWithLargestSize(self, partitions):
        max = -1;
        pid = -1;
        for i in range (len(partitions)):
            if not self.spilledStatus[i] and len(partitions[i].frames) > 0:
                if len(partitions[i].frames) > max:
                    max=len(partitions[i].frames)
                    pid = i
        return pid


    def getPartitionWithLargestRecord(self, partitions):
        max = -1;
        pid = -1;
        for i in range (len(partitions)):
            if not self.spilledStatus[i] and len(partitions[i].frames) > 0:
                if partitions[i].numberOfInMemRecords > max:
                    max=partitions[i].numberOfInMemRecords
                    pid = i
        return pid

    #AsterixDB Deafult method
    def getPartitionWithLargestSizeSelf(self, victim, partitions):
        if partitions[victim].numberOfRecords > 0:
            return victim
        return self.getPartitionWithLargestSize(partitions)


    def getPartitionWithSmallestSize(self, partitions):
        min = sys.maxsize * 2 + 1;
        pid = -1;
        for i in range(len(partitions)):
            if not self.spilledStatus[i]:
                if 0 < len(partitions[i].frames) < min:
                    min = len(partitions[i].frames)
                    pid = i
        return pid

    def getPartitionWithSmallestRecord(self, partitions):
        min = sys.maxsize * 2 + 1;
        pid = -1;
        for i in range (len(partitions)):
            if not self.spilledStatus[i] and len(partitions[i].frames) > 0:
                if 0 < partitions[i].numberOfInMemRecords < min:
                    min = partitions[i].numberOfInMemRecords
                    pid = i
        return pid


    def getPartitionWithMedianSize(self, partitions):
        inMem=[]
        for p in range(len(partitions)):
            if not self.spilledStatus[p] and len(partitions[p].frames) > 0:
                inMem.append(partitions[p]);
        inMem.sort(key=lambda x : len(x.frames), reverse=True)
        if len(inMem) == 0:
            return -1
        if len(inMem)%2 == 0:
            median = len(inMem)/2
        else:
            median = (len(inMem)+1)/2
        return inMem[median]


    def getPartitionWithMedianRecord(self, partitions):
        inMem=[]
        for p in range(len(partitions)):
            if not self.spilledStatus[p] and len(partitions[p].frames) > 0:
                inMem.append(partitions[p]);
        inMem.sort(key=lambda x : x.numberOfRecords, reverse=True)
        if len(inMem) == 0:
            return -1
        if len(inMem)%2 == 0:
            median = len(inMem)/2
        else:
            median = (len(inMem)+1)/2
        return inMem[median]


    def getPartitionWithMaxSizeMinRecord(self, partitions):
        ratio=-1
        pids=[]
        for p in range(len(partitions)):
            if not self.spilledStatus[p] and len(partitions[p].frames) > 0:
                pRatio = len(partitions.frames)/partitions[p].getNumberOfRecords
                if pRatio > ratio:
                    pids=[]
                    pids.append(p)
                    ratio=pRatio
                if pRatio == ratio:
                    pids.append(p)
        maxSize=0
        resPid=-1
        for n in pids:
            if len(partitions[n].frames) > maxSize:
                maxSize=len(partitions[n].frames)
                resPid=n

        return resPid



    def getPartitionRandomly(self, partitions):
        inMem = []
        for p in range(len(partitions)):
            if not self.spilledStatus[p] and len(partitions[p].frames) > 0:
                inMem.append(partitions[p]);
        index=rand.randint(len(inMem))
        if index >= len(inMem):
            index = len(inMem)-1
        return index

    def getSpilledPartitionWithLargestSize(self, partitions):
        max = -1;
        pid = -1;
        for i in range (len(self.spilledStatus)):
            if  self.spilledStatus[i] and len(partitions[i].frames) > 0:
                if len(partitions[i].frames) > max:
                    max=len(partitions[i].frames)
                    pid = i

        return pid