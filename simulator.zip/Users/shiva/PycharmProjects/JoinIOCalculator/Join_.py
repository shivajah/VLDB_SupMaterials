import math

from Config import *
from VictimSelectionPolicy import *
import random
#TODO:This program works well for a fixed record size (not variable) and it should be smaller than a frame size.
class GrowthConstraint(Enum):
    GS=1
    NGNS=2

class Frame:
    def __init__(self, size=32768):
        self.originalSize = size
        self.free = size

    def insertRecord(self, recordSize=0):
        if self.free >= recordSize:
            self.free -= recordSize
            return True
        else:
            return False

    def getOriginalSize(self):
        return self.originalSize


class Partition:
    def __init__(self, pid):
        self.pid = pid
        self.size = 0  # on the disk (bytes)
        self.frames = []  # in memory Frames
        self.diskFrames = []
        self.numberOfInMemRecords=0#in memory
        self.totalNumberOfRecords=0;

    def getSumOfFramesInBytes(self):
            total = 0
            for f in self.frames:
               # f = Frame(frame)
                total += f.originalSize - f.free
            return total


class JOINPHASE(Enum):
    BUILD =1
    PROBE = 2


class MemoryManager:

    def __init__(self, memory, frameSize, numOfPartitions, GrowthC,spilledStatus):
        self.freeMemory=memory
        self.memoryBudget = memory
        self.frameSize = frameSize
        self.buildPartitions = {i : Partition(i) for i in range(numOfPartitions)}
        self.probePartitions = {i : Partition(i) for i in range(numOfPartitions)}
        self.GrowthC = GrowthC
        self.spilledStatus = spilledStatus

    def appendFrame(self, partitionNumber, recordSize, phase):
        # gets a frame with the either size of a regular frame or size of a record if record is larger than a regular frame.
        if self.freeMemory and self.freeMemory - (sum(self.spilledStatus)*self.frameSize) >= recordSize :
            neededSize = max(self.frameSize, recordSize)
            f = Frame(neededSize)
            if phase == JOINPHASE.BUILD:
                self.buildPartitions[partitionNumber].frames.append(f)
            else:
                self.probePartitions[partitionNumber].frames.append(f)
            self.freeMemory -= neededSize
            return True
        else:
            return False

    def getLastFrameOfPartition(self, partitionNumber, phase):
        if partitionNumber not in self.buildPartitions.keys():
            raise ValueError('Invalid partition number: ' + str(partitionNumber))
        else:
            if phase == JOINPHASE.BUILD:
                p = self.buildPartitions[partitionNumber].frames
            else:
                p = self.probePartitions[partitionNumber].frames
            if len(p) == 0:
                    return None
            else:
                return p[len(p) - 1]

    def getLastFrameOfPartitionOrCreateIfNotExists(self, partitionNumber, recordSize, phase):
       lastFrame = self.getLastFrameOfPartition(partitionNumber, phase)
       if lastFrame is None:
           appended = self.appendFrame(partitionNumber, recordSize, phase)
           if not appended:
               return None
           lastFrame = self.getLastFrameOfPartition(partitionNumber, phase)
       return lastFrame


    def insertRecordIntoPartition(self, recordSize, partitionNumber, phase):
        if partitionNumber not in self.buildPartitions.keys():
            raise ValueError('Cannot insert into a partition with invalid partition number: ' + str(partitionNumber))
        #get last frame in the partition
        frame = self.getLastFrameOfPartitionOrCreateIfNotExists(partitionNumber, recordSize, phase)
        if frame is None:
            return False

        if not frame.insertRecord(recordSize):
            #GrowSteal or NoGrow-NoSteal
            if (self.GrowthC == GrowthConstraint.NGNS.name and phase == JOINPHASE.BUILD and self.spilledStatus[partitionNumber]):
                if len(self.buildPartitions[partitionNumber].frames) >= 1:
                    return False
            #GrowSteal
            appendedFrame = self.appendFrame(partitionNumber, recordSize, phase)
            if not appendedFrame: #no memory left, need to select the victim
                return False
            else:
                inserted = self.getLastFrameOfPartition(partitionNumber, phase).insertRecord(recordSize)
                assert inserted
        if phase == JOINPHASE.BUILD:
            self.buildPartitions.get(partitionNumber).numberOfInMemRecords += 1
            self.buildPartitions.get(partitionNumber).totalNumberOfRecords += 1
        else :
            self.probePartitions.get(partitionNumber).numberOfInMemRecords += 1
            self.probePartitions.get(partitionNumber).totalNumberOfRecords += 1
        return True


    def spillInMemoryManager(self, partitionNumber, phase):
        if phase == JOINPHASE.BUILD:
            partitions = self.buildPartitions
        else:
            partitions = self.probePartitions
        for fr in partitions[partitionNumber].frames:
            self.freeMemory += fr.getOriginalSize()
        partitions[partitionNumber].size += len(partitions[partitionNumber].frames) * self.frameSize
        partitions[partitionNumber].diskFrames.extend(partitions[partitionNumber].frames)
        partitions[partitionNumber].frames = []
        partitions[partitionNumber].numberOfInMemRecords = 0
        self.spilledStatus[partitionNumber] = True


    def getInMemorySize(self, phase):
        sum=0
        if phase == JOINPHASE.BUILD:
            partitions = self.buildPartitions
        else:
            partitions = self.probePartitions
        for p in partitions:
            if self.spilledStatus[p] ==  False:
                sum += partitions[p].getSumOfFramesInBytes()
        return sum




class Join_:
    def __init__(self, config, id = 0):
        self.config = config
        self.numOfPartitions = min(self.config.numPartitions,(int) (self.config.memSize/self.config.frameSize))
        self.recordSizeMin = config.recordSizeMin
        self.recordSizeMax = config.recordSizeMax
        self.frameSize = config.frameSize
        self.GrowthC = config.GrowthC
        self.VS = config.VS
        self.fudge = config.fudge
        self.build = None
        self.probe = None
        self.mem = config.memSize
        self.spilledStatus = [False] * self.numOfPartitions
        self.freeMem = self.mem
        self.id = id
        self.stats_ = None
        self.numPartitionsFixed = self.config.numPartitionsFixed
        self.memoryManager = MemoryManager(self.mem, self.frameSize, self.numOfPartitions, self.GrowthC, self.spilledStatus)

    def stats(self):
        if self.stats_ is None:
            #print("Join-init:")
            self.stats_ = self.build.stats() + self.probe.stats()
        return self.stats_

    def spilledPartitions(self):
        return sum(self.spilledStatus)

    def isSpilled(self, i):
        return self.spilledStatus[i]

    def spill(self, i, phase):
        self.spilledStatus[i] = True
        self.memoryManager.spillInMemoryManager(i, phase)

    def unspill(self, i): #after build is over, when we try to bring as many partition as possible, this method unspills those that get back in the memory.
        self.spilledStatus[i] = False

    def getLeftOverMemoryInBytes(self):
        outputFramesForSpilledPartitions = sum(self.spilledStatus) # saves at least 1 frame for each spilled partition
        self.freeMem = self.mem - ((self.build.memoryUsedInFrames() + outputFramesForSpilledPartitions) * self.frameSize)
        return self.freeMem

    def getRecursionDepth(self):
        #or we could return the maximum join id
        if len(self.probe.joins) == 0:
            return 0
        return max(j.getRecursionDepth() for j in self.probe.joins) + 1

    def run(self):
        self.build = Build(self.config.buildSize, self.recordSizeMin, self.recordSizeMax, self.frameSize, self.mem, self)
        self.build.run()
        self.build.buildclose()
        self.probe = Probe(self.config.probeSize, self)
        self.probe.init()
        self.probe.run()
        self.stats()
        self.build.buildstats_.recursionDepth = self.probe.probestats_.recursionDepth
        self.stats_.recursionDepth = self.probe.probestats_.recursionDepth

    def __str__(self):
        return "\"Join\" : id %s, partitions: %s, numPartitions_spilled: %s, buildSize: %s, probeSize: %s, mem: %s, freeMem: %s" %(self.id,self.numOfPartitions, self.spilledPartitions() ,self.config.buildSize, self.config.probeSize, self.mem, self.freeMem)



class Build:
    def __init__(self, buildSize, recordSizeMin, recordSizeMax, frameSize, mem, join):#all in frames
        self.buildSize = buildSize
        self.recordSizeMin = recordSizeMin
        self.recordSizeMax = recordSizeMax
        self.frameSize = frameSize
        self.mem = mem
        self.join = join
        #print("in build init")
        self.buildstats_ = Stats(self.frameSize,0,0,self.join,[],[],JOINPHASE.BUILD)
        self.VS = SelectVictim(self.join.VS, self.join.memoryManager,self.join.spilledStatus)

    def stats(self):
        return self.buildstats_


    def run(self):
        #buildSizeInFrames = (int)(self.buildSize / self.frameSize)
        #recordsInEachFrame = (int)(self.frameSize/self.recordSize)
        ############################# BUILD PHASE ###############################
        fCount=0
        readInSizeInBytes = 0;
        readInSizeInFrames = 0;
        remainderOfIncomingFrame = self.frameSize
        #for frameId in range(buildSizeInFrames):
        while readInSizeInBytes < self.buildSize:
            #readInSizeInFrames += 1
            random.seed(readInSizeInFrames+self.join.id)
            #fCount +=1
            recordSize = int(random.uniform(self.recordSizeMin, self.recordSizeMax))
           #read build relation frame by frame
            if remainderOfIncomingFrame - recordSize < 0:
                #new frame
                fCount += 1
                readInSizeInFrames += 1
                remainderOfIncomingFrame = self.frameSize

            remainderOfIncomingFrame -= recordSize
            readInSizeInBytes+=recordSize
        #for record in range(recordsInEachFrame):
            insertingPartition = random.randint(0,self.join.numOfPartitions-1)
            #print("inserting partition- in build: ", insertingPartition, " join id: ", self.join.id, " frameID: ", frameId)
            assert insertingPartition >= 0 and insertingPartition < self.join.numOfPartitions
            while not self.join.memoryManager.insertRecordIntoPartition(recordSize,insertingPartition, JOINPHASE.BUILD):
                #select vitim partition
                    #NoGrowNoSteal
                    victim=-1
                    if self.join.memoryManager.GrowthC == GrowthConstraint.NGNS.name:
                        if len(self.join.memoryManager.buildPartitions[insertingPartition].frames) > 0:
                            victim = int(insertingPartition)
                        else:
                            victim = int(self.VS.select(insertingPartition, JOINPHASE.BUILD))#only in memory partitions
                    else:#GrowSteal
                        victim = int(self.VS.getSpilledPartitionWithLargestSize(self.join.memoryManager.buildPartitions));
                        if victim < 0:
                            victim = self.VS.select(insertingPartition, JOINPHASE.BUILD) #only in memory partitions

                    if victim < 0:
                        print('Victim cannot be less than 0.')
                        continue
                        #raise ValueError('Victim cannot be less than 0.')
                    self.buildstats_.writeBytes += self.join.memoryManager.buildPartitions[victim].getSumOfFramesInBytes()
                    self.buildstats_.writeFrames.append(len(self.join.memoryManager.buildPartitions[victim].frames))
                    self.join.spill(victim, JOINPHASE.BUILD)




        # Reading of base relations should not be counted. Only intermediate results.
        if self.join.id != 0:
            self.buildstats_.readBytes += readInSizeInBytes
            self.buildstats_.readFrames.append(readInSizeInFrames)
            fCount =0


    def memoryUsedInFrames(self):
        #used for calculating the left over memory at the end of the build
       size = 0
       for i in range(self.join.numOfPartitions):
           if not self.join.spilledStatus[i]:
               size += len(self.join.memoryManager.buildPartitions[i].frames)
       return size


    def buildclose(self):
       #write the leftover parts of each spilled partition to the disk
        for p in range (len(self.join.memoryManager.buildPartitions)):
            if self.join.spilledStatus[p] and len(self.join.memoryManager.buildPartitions[p].frames) > 0:
                self.buildstats_.writeBytes += self.join.memoryManager.buildPartitions[p].getSumOfFramesInBytes()
                self.buildstats_.writeFrames.append(len(self.join.memoryManager.buildPartitions[p].frames))
                self.join.spill(p, JOINPHASE.BUILD)
        self.bringPartitionsBackinIfPossible()

    def bringPartitionsBackinIfPossible(self):
        freeMem = self.join.memoryManager.freeMemory - (sum(self.join.spilledStatus) * self.frameSize)
        assert freeMem >=0
        for p in range(self.join.numOfPartitions):
            if self.join.spilledStatus[p] and self.join.memoryManager.buildPartitions[p].size < freeMem:
                self.join.memoryManager.buildPartitions[p].frames = self.join.memoryManager.buildPartitions[p].diskFrames #in memory frames
                self.buildstats_.readBytes += self.join.memoryManager.buildPartitions[p].size
                self.buildstats_.readFrames.append(self.join.memoryManager.buildPartitions[p].frames)
                self.join.memoryManager.freeMemory -= self.join.memoryManager.buildPartitions[p].size
                freeMem -= self.join.memoryManager.buildPartitions[p].size
                self.join.memoryManager.buildPartitions[p].size=0
                self.join.memoryManager.buildPartitions[p].diskFrames=[]
                self.join.unspill(p)
            else:
                continue
        assert (self.join.memoryManager.freeMemory - (sum(self.join.spilledStatus) * self.frameSize) >= 0 )

class Probe:
    def __init__(self, probeSize, parentJoin):
        self.joins = []
        self.parentJoin = parentJoin
        self.probeSize = probeSize # size of probe relation in frames
        self.probestats_ = Stats(self.parentJoin.frameSize,0,0,None,[],[],JOINPHASE.PROBE)
        self.VS = SelectVictim(self.parentJoin.VS, self.parentJoin.memoryManager, self.parentJoin.spilledStatus)

    def stats(self):
        max_recursionDepth = 0 if len(self.joins) == 0 else max(j.stats().recursionDepth for j in self.joins) +1
        stats = self.probestats_ + sum([j.stats() for j in self.joins], Stats(self.parentJoin.frameSize,0,0,None,[],[],None))
        stats.recursionDepth = max_recursionDepth
        return stats

    def init(self):

        #probeSizeInFrames = (int)(self.probeSize/self.parentJoin.frameSize)
        #recordsInEachFrame = (int)(self.parentJoin.frameSize/self.parentJoin.recordSize)
        ############################# PROBE PHASE ###############################
        fCount=0
        totalReadInSizeInbBytes=0
        remainderOfIncomingFrame = self.parentJoin.frameSize
        #for frameId in range(probeSizeInFrames):
        while totalReadInSizeInbBytes < self.probeSize:
            # fCount += 1
            random.seed(fCount+self.parentJoin.id)

            recordSize = int(random.uniform(self.parentJoin.recordSizeMin, self.parentJoin.recordSizeMax))
            if remainderOfIncomingFrame - recordSize >= 0:
                remainderOfIncomingFrame -= recordSize
                totalReadInSizeInbBytes += recordSize
                insertingPartition = random.randint(0, self.parentJoin.numOfPartitions-1)
                assert insertingPartition >= 0 and insertingPartition < self.parentJoin.numOfPartitions
                if self.parentJoin.isSpilled(insertingPartition):
                    # Try to insert in the partition as the corresponding partition in build phase is spilled
                    if not self.parentJoin.memoryManager.insertRecordIntoPartition(recordSize,insertingPartition,JOINPHASE.PROBE):
                        if recordSize <= self.parentJoin.frameSize and len(self.parentJoin.memoryManager.probePartitions[insertingPartition].frames) > 0:#modest size ==> half full
                            victim = insertingPartition
                        else:
                            victim = self.VS.getSpilledPartitionWithLargestSize(self.parentJoin.memoryManager.probePartitions)
                        if victim >= 0 and len(self.parentJoin.memoryManager.probePartitions[victim].frames)*self.parentJoin.frameSize >= recordSize:
                            self.probestats_.writeBytes += self.parentJoin.memoryManager.probePartitions[victim].getSumOfFramesInBytes()
                            self.probestats_.writeFrames.append(
                                len(self.parentJoin.memoryManager.probePartitions[victim].frames))
                            self.parentJoin.spill(victim, JOINPHASE.PROBE)
                            if not self.parentJoin.memoryManager.insertRecordIntoPartition(recordSize,insertingPartition,JOINPHASE.PROBE):
                                raise ValueError('Probe insertion failed after victim selection')
                        else:
                            victim = self.VS.getPartitionWithLargestSize(self.parentJoin.memoryManager.buildPartitions)
                            if victim < 0:
                                print(insertingPartition)
                                print(self.parentJoin.numOfPartitions)
                                print(fCount)
                                print(self.parentJoin.build.buildSize)
                                print('Victim was not found in probe')
                                continue
                            #raise ValueError('Victim was not found')
            else:
                # new frame
                fCount +=1
                remainderOfIncomingFrame = self.parentJoin.frameSize
            # Reading of base relations should not be counted. Only intermediate results.
            if self.parentJoin.id != 0:
                self.probestats_.readBytes += totalReadInSizeInbBytes
                self.probestats_.readFrames.append(fCount)
                fCount = 0

        self.probeclose()

    def probeclose(self):
        # write the leftover parts of each spilled partition to the disk
        for p in range (len(self.parentJoin.memoryManager.probePartitions)):
            if self.parentJoin.spilledStatus[p] and len(self.parentJoin.memoryManager.probePartitions[p].frames) > 0:
                self.probestats_.writeBytes += self.parentJoin.memoryManager.probePartitions[p].getSumOfFramesInBytes()
                self.probestats_.writeFrames.append(
                    len(self.parentJoin.memoryManager.probePartitions[p].frames))
                self.parentJoin.spill(p, JOINPHASE.PROBE)



    def run(self):
        for i in range(self.parentJoin.numOfPartitions):
            if self.parentJoin.isSpilled(i):
                # if (self.parentJoin.memoryManager.buildPartitions[i].size >= 0.8 * self.parentJoin.build.buildSize ) :
                #     self.parentJoin.build.buildstats_.read.append(self.parentJoin.memoryManager.buildPartitions[i].size/self.parentJoin.frameSize)
                #     self.parentJoin.
                if self.parentJoin.numPartitionsFixed == True:
                    num = self.parentJoin.numOfPartitions
                else:
                    num = math.ceil((((self.parentJoin.memoryManager.buildPartitions[i].size/self.parentJoin.frameSize)*self.parentJoin.config.fudge) - (self.parentJoin.mem/self.parentJoin.frameSize))
                                    /((self.parentJoin.mem/self.parentJoin.frameSize) - 1))+1
                numberOfPartitions = max(2,num)
                c = Config(self.parentJoin.memoryManager.buildPartitions[i].size,
                           self.parentJoin.memoryManager.probePartitions[i].size,
                           self.parentJoin.mem,
                           self.parentJoin.recordSizeMin,
                           self.parentJoin.recordSizeMax,
                           self.parentJoin.frameSize,
                           numberOfPartitions,
                           self.parentJoin.VS,
                           self.parentJoin.GrowthC,
                           self.parentJoin.numPartitionsFixed,
                           self.parentJoin.fudge)
                #print (c.__str__())
                nextJoin = Join_(c, self.parentJoin.id + 1)
                self.joins.append(nextJoin)
                nextJoin.run()



    def __str__(self):
        return "\"Probe\" : partitions: %s, data_size: %s" %(self.partitions, self.size)



class Stats:
    seekTime_HDD = 12 #ms
    rotational_HDD = 4.17 #ms
    transferRate_HDD = 1.92 # Frames/ms or 0.06MB/ms

    seqR_SSD = 96 #Frames/ms or  3 MB/ms
    seqW_SSD = 36.8 # Frames/ms or 1.15 MB/ms
    randomR_SSD = 360 #iopms
    randomW_SSD = 35 #iopms(frame-based) or 280 iopms (4k-based) ==> calculation (280*4*1024)/32768


    def __init__(self, frameSize, writeBytes, readBytes, join, writeFrames=[], readFrames=[], phase=JOINPHASE.BUILD):
        self.readBytes=readBytes
        self.writeBytes=writeBytes
        self.readFrames=readFrames
        self.writeFrames=writeFrames
        self.recursionDepth = 0
        self.frameSize = frameSize
        self.join = join
        self.phase = phase

    @property
    def totalWBytes(self):
        return self.writeBytes

    @property
    def totalWFrames(self):
        tw = 0
        for w in self.writeFrames:
            if isinstance(w,int):
                tw += w
        return tw

    @property
    def RWFrames(self):
        tw=0
        for w in self.writeFrames:
            if isinstance(w,int) and w > 0:
                tw +=1
        return tw

    @property
    def SWFrames(self):
        return self.totalWFrames - self.RWFrames

    @property
    def RW(self):
        return self.RWFrames * self.frameSize

    @property
    def SW(self):
        return self.SWFrames * self.frameSize

    @property
    def totalRFrames(self):
        tr = 0
        for r in self.readFrames:
            if isinstance(r, int):
                tr += r
        return tr
    @property
    def totalRBytes(self):
        return self.readBytes
    
    @property
    def RRFrames(self):
        tr = 0
        for r in self.readFrames:
            if isinstance(r, int) and r > 0:
                tr += 1
        return tr

    @property
    def SRFrames(self):
        return self.totalRFrames - self.RRFrames

    @property
    def SR(self):
        return self.SRFrames * self.frameSize

    @property
    def seeks(self):
        return self.RWFrames+self.RRFrames


    @property
    def totalIOFrames(self):
        total=0
        for i in self.readFrames:
            if isinstance(i, int):
                total += i;
        for i in self.writeFrames:
            if isinstance(i, int):
                total += i;
        return total

    @property
    def totalIOBytes(self):
        return self.readBytes + self.writeBytes


    # @property
    # def totalTimeHDD(self):
    #     # TODO:SHIVA: transferTime should be based on dd/iodirect/jaydio program
    #     return (len(self.read) + len(self.write)) * (Stats.seekTime_HDD + 0.5 * Stats.rotational_HDD) + (self.totalIO / Stats.transferRate_HDD)

    # @property
    # def totalTimeSSD(self):
    #     return (self.seqR / Stats.seqR_SSD) + (self.SW / Stats.seqW_SSD) + (self.RW / Stats.randomW_SSD)



    @staticmethod
    def getAttrNames():
        return ['totalWBytes','totalWFrames','RWFrames','SWFrames','RW','SW','totalRFrames','totalRBytes','RRFrames','SRFrames','SR','seeks','totalIOFrames','totalIOBytes', 'recursionDepth']


    def __add__(self, other):
        new_writesFrames = self.writeFrames.copy()
        new_readsFrames = self.readFrames.copy()

        if len(other.writeFrames) > 0:
            new_writesFrames += other.writeFrames
        if len(other.readFrames) > 0:
            new_readsFrames += other.readFrames
        new_writeBytes = self.writeBytes + other.writeBytes
        new_readBytes = self.readBytes + other.readBytes
        return Stats(self.frameSize, new_writeBytes, new_readBytes, None, new_writesFrames, new_readsFrames, None)

    def __str__(self):
        res = ("\ttotalW(Bytes): %d \ttotalR(Bytes): %d \ttotalW(frames): %d\tRW(Frames): %d\tSW(Frames): %d \tRW(bytes): %d\tSW(bytes): %d\t totalRFrames: %d\t RRFrames: %d\tSRFrames: %d\tSR(bytes): %d\tseeks: %d\ttotalIO(Frames): %d\ttotalIO(bytes): %d\ttotalIO(frames): %d\trecursionDepth: %d"
                % (self.totalWBytes, self.totalRBytes, self.totalWFrames, self.RWFrames,  self.SWFrames, self.RW, self.SW,self.totalRFrames, self.RRFrames, self.SRFrames, self.SR, self.seeks, self.totalIOFrames, self.totalIOBytes,self.totalIOFrames , self.recursionDepth));
        if self.phase!=None and self.phase == JOINPHASE.BUILD:
            res += "inMemoryData (Bytes):"+ str(self.join.memoryManager.getInMemorySize(JOINPHASE.BUILD))
        return res
